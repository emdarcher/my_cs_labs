#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    printf("\t\t\t\tBasic BYU Trivia\n\n");
    printf("\t\tQuestions\t\t\t\tAnswers\n\n");
    printf("What was the original name of BYU?\t\t%s\n",
            "Brigham Young Academy");
    printf("When was BYA established?\t\t\t%i\n", 1875);
    printf("Who was the first \"permanent\" principal of BYA?\t%s\n",
            "Karl Maeser");
    printf("When did BYA become BYU?\t\t\t%i\n", 1903);
    printf("To what sports conference do we belong?\t\t%s\n",
            "Independent (Football)");
    printf("When did BYU win te national football title?\t%i\n",
            1984);
    printf("Who won the Heisman Trophy in 1990?\t\t%s\n",
            "Ty Detmer");
    return 0;
}
